<?php
/**
 * mongo数据库表备份
 * 例子：
 * php /data/www/php-script/artisan Back:UpDb --orgdb='{"database":"bas","host":"127.0.0.1","port":"27017","username":"root","password":"root","dbs":["bas"]}' --trgdb='{"database":"bas","host":"10.20.20.61","port":"27017","username":"admin","password":"admin","dbs":["bas"]}'
 */

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;

class BackUpDb extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Back:UpDb
        {--orgdb= : 原始数据库信息, eg {"database":"bas","host":"127.0.0.1","port":"27017","username":"root","password":"root","dbs":["bas"]}
        {--trgdb= : 目标数据库信息, eg {"database":"bas","host":"10.20.20.61","port":"27017","username":"admin","password":"admin","dbs":["bas"]}}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '备份mongo库表';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        //获取输入参数
        self::getInput();
        $table = isset($this->orgdb['tables'])?$this->orgdb['tables']:'';
        $courselog = "{$this->mongobak}courselog/{$this->orgdb['host']}{$this->orgdb['port']}{$this->orgdb['database']}{$table}.log";

        if (!file_exists($courselog)){
            toLog(time(), "{$this->orgdb['host']}{$this->orgdb['port']}{$this->orgdb['database']}{$table}.log", "{$this->mongobak}courselog", 0);
            //var_dump($this->input);sleep(10);die;
            echo "库表备份任务开始时间：" . date("Y-m-d H:i:s", time()) . PHP_EOL;
            //执行数据备份
            self::proData($this->orgdb, $this->trgdb);
            echo "库表备份任务结束时间：" . date("Y-m-d H:i:s", time()) . PHP_EOL;

            shell_exec("rm -rf {$courselog}");
        }
        die;
    }

    /**
     * 处理数据
     */
    private function proData($orghost, $trghost)
    {

        $table = isset($orghost['tables']) ? "-c {$orghost['tables']}" : "";
        $tablebson = isset($orghost['tables']) ? "/{$orghost['tables']}.bson" : "";

        $expcmd = "{$this->sudo}{$this->mongodir}mongodump -h {$orghost['host']} --port {$orghost['port']} -u {$orghost['username']} -p '{$orghost['password']}' --authenticationDatabase admin -d {$orghost['database']} {$table} -o {$this->mongobak}";
        exec($expcmd, $res);

        $impcmd = "{$this->sudo}{$this->mongodir}mongorestore -h {$trghost['host']} --port {$trghost['port']} -u {$trghost['username']} -p '{$trghost['password']}' --authenticationDatabase admin -d {$trghost['database']} {$table} {$this->mongobak}{$orghost['database']}{$tablebson}";
        exec($impcmd, $res);

        $url = "{$this->mongobak}{$orghost['database']}{$tablebson}";
        echo $url;
        if (file_exists($url) && stripos($url, '.bson')){
            $rmcmd = "{$this->sudo}rm -rf {$url}";
            shell_exec($rmcmd);
        }

    }

    /**
     *  获取输入参数
     * @return array
     */
    private function getInput()
    {

        //获取原始数据库信息
        if ($this->option('orgdb')) {

            $this->orgdb = json_decode($this->option('orgdb'), true);
        }

        //获取原始数据库信息
        if ($this->option('trgdb')) {

            $this->trgdb = json_decode($this->option('trgdb'), true);
        }

        $this->input = ['orgdb' => $this->orgdb, 'trgdb' => $this->trgdb];
        return $this->input;
    }


}
