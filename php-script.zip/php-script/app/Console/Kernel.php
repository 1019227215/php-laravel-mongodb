<?php

namespace App\Console;

use App\Console\Commands\AdvData;
use App\Console\Commands\AdvDataSum;
use App\Console\Commands\AdvEmailDispense;
use App\Console\Commands\AdvRemained;
use App\Console\Commands\AdvRetainResult;
use App\Console\Commands\BackCes;
use App\Console\Commands\BackUpData;
use App\Console\Commands\BackUpDb;
use App\Console\Commands\BackUpOplog;
use App\Console\Commands\GamePay;
use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [

        /***
         * af广告任务开始
         */
        //备份数据
        BackUpData::class,
        //跑库表
        BackUpDb::class,
        //跑oplog
        BackUpOplog::class,

        //测试
        BackCes::class,
        /***
         * af广告任务结束
         */




        
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        //
    }
}
