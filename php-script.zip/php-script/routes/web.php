<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/test', function () use ($app) {
    //


//    $obj = new \App\Jobs\Day\LtvDJob(108, 20180117, 1);
//    $obj->handle();
});
